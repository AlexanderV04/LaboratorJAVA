package ex1;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record Carte(String titlul, String autorul, int anul) {
}
