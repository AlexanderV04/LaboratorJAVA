package problema_lab4;

public enum ModTiparire {
    color,
    albnegru
}
