package problema_lab4;

public enum StareEchipamente {
    achizitionat,
    expus,
    vandut
}
