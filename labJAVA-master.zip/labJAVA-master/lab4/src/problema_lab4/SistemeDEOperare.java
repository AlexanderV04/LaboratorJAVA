package problema_lab4;

public enum SistemeDEOperare {
    windows,
    linux
}
