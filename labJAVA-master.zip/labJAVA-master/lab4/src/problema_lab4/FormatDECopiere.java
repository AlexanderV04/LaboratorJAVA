package problema_lab4;

public enum FormatDECopiere {
    A3,
    A4
}
